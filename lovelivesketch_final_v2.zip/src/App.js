import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { v4 as uuidv4 } from "uuid";

export default function LoveLiveSketch() {
  const [loveTexts, setLoveTexts] = useState([]);
  const [inputValue, setInputValue] = useState("");

  const handleSend = () => {
    if (inputValue.trim() !== "") {
      setLoveTexts([...loveTexts, { id: uuidv4(), text: inputValue }]);
      setInputValue("");
    }
  };

  return (
    <div className="min-h-screen bg-pink-200 flex flex-col items-center p-4">
      <h1 className="text-3xl font-bold text-red-500 mb-4">What is your Love like?</h1>
      <div className="flex gap-2 mb-6">
        <input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="What is your Love?"
          className="p-2 rounded-lg border-2 border-red-300"
        />
        <button onClick={handleSend} className="bg-red-500 text-white p-2 rounded-lg">Send!</button>
      </div>
      <div className="relative w-full h-screen overflow-hidden">
        <AnimatePresence>
          {loveTexts.map((love) => (
            <motion.div
              key={love.id}
              className="absolute flex items-center justify-center w-20 h-20 bg-red-400 text-white font-bold text-center p-2 rounded-full shadow-lg"
              style={{ left: `${Math.random() * 80}%` }}
              initial={{ top: "100%", opacity: 0 }}
              animate={{ top: "10%", opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 3, ease: "easeOut" }}
            >
              {love.text}
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}