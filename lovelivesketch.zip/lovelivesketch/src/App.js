import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { v4 as uuidv4 } from "uuid";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, Tab } from "@/components/ui/tabs";
import { io } from "socket.io-client";

const socket = io("https://lovelivesketch.com");

export default function LoveLiveSketch() {
  const [tab, setTab] = useState("loveInput");
  const [loveTexts, setLoveTexts] = useState([]);
  const [inputValue, setInputValue] = useState("");

  useEffect(() => {
    socket.on("newLove", (text) => {
      setLoveTexts((prev) => [...prev, { id: uuidv4(), text }]);
    });
    return () => {
      socket.off("newLove");
    };
  }, []);

  const handleSend = () => {
    if (inputValue.trim() !== "") {
      socket.emit("sendLove", inputValue);
      setInputValue("");
    }
  };

  return (
    <div className="min-h-screen bg-pink-200 flex flex-col items-center p-4 relative overflow-hidden">
      <Tabs value={tab} onChange={setTab} className="mb-6">
        <Tab label="What is your Love like?" value="loveInput" />
        <Tab label="Love Live Sketch" value="loveSketch" />
      </Tabs>
      {tab === "loveInput" && (
        <div className="flex gap-2">
          <Input 
            value={inputValue} 
            onChange={(e) => setInputValue(e.target.value)} 
            placeholder="What is your Love?" 
            className="p-2 rounded-lg border-2 border-red-300" 
          />
          <Button onClick={handleSend} className="bg-red-500 text-white p-2 rounded-lg">Send!</Button>
        </div>
      )}
      {tab === "loveSketch" && (
        <div className="relative w-full h-screen overflow-hidden">
          <AnimatePresence>
            {loveTexts.map((love) => (
              <FloatingHeart key={love.id} text={love.text} />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

const FloatingHeart = ({ text }) => {
  const [position, setPosition] = useState({
    left: Math.random() * 80 + "%",
    top: "100%",
  });

  return (
    <motion.div
      className="absolute flex items-center justify-center w-20 h-20 bg-red-400 text-white font-bold text-center p-2 rounded-full shadow-lg"
      style={{ left: position.left, width: '60px', height: '60px', borderRadius: '50%' }}
      initial={{ top: "100%", opacity: 0, scale: 0.8 }}
      animate={{ top: "10%", opacity: 1, scale: 1, rotate: [0, 10, -10, 10, -10, 0] }}
      exit={{ opacity: 0 }}
      transition={{ duration: 3, ease: "easeInOut" }}
    >
      {text}
    </motion.div>
  );
};
